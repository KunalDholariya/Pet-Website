<?php
define('TITLE', 'Pet Service');
define('PAGE', 'petservice');
include('includes/header.php');
include('../dbConnection.php');
?>

<div class="col-sm-9 col-md-10 mt-5 text-center">
  <!--Table-->
  <p class=" bg-dark text-white p-2">Pet Care Services Provided By Our Professional</p>
  <p> Below rates may differ from pets to pets. To know more abouts the you may visit our store or call on given no. 7620134556</p>

  <!DOCTYPE html>
<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>

<table>
  <tr>
    <th>Services</th>
    <th>Dog</th>
    <th>Cat</th>
    <th>Rabbit</th>
    <th>Birds</th>
    <th>Small Pets</th>
  </tr>
  <tr>
    <td>Pet Grooming</td>
    <td>Rs. 2500</td>
    <td>Rs. 2000</td>
    <td>Rs. 1500</td>
    <td>Rs. 1500</td>
    <td>Rs. 1000</td>
  </tr>
  <tr>
    <td>Hair Cut</td>
    <td>Rs. 1000</td>
    <td>Rs. 700</td>
    <td>Rs. 500</td>
    <td>Rs. 500</td>
    <td>Rs. 400</td>
  </tr>
  <tr>
    <td>Pet Training per hour</td>
    <td>Rs. 1500</td>
    <td>Rs. 1000</td>
    <td>-</td>
    <td>-</td>
    <td>-</td>
  </tr>
  <tr>
    <td>Pet Boarding Per Hour</td>
    <td>Rs. 1500</td>
    <td>Rs. 1500</td>
    <td>Rs. 1000</td>
    <td>Rs. 1000</td>
    <td>Rs. 700</td>
  </tr>
  <tr>
    <td>Homestay Per Hour</td>
    <td>Rs. 3500</td>
    <td>Rs. 3000</td>
    <td>Rs. 2500</td>
    <td>Rs. 2500</td>
    <td>Rs. 1500</td>
  </tr>
</table>

</body>
</html>




<?php
include('includes/footer.php'); 
$conn->close();
?>