<?php
define('TITLE', 'Pet Foods');
define('PAGE', 'Petfoods');
include('includes/header.php');
include('../dbConnection.php');
?>

<div class="col-sm-9 col-md-10 mt-5 text-center">
  <p class=" bg-dark text-white p-2">Pet Foods</p>
  <p>We are not providing online delivery services, you have to visit our store to purchase these products.</p>

  <div class="row mt-5">
        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 1st Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/food1.jpg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Adult Dog Food With Chicken And Rice</h4>
              <p class="card-text">With 80% Chicken <br> MRP-1000 <br> You Save-100</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold"> Our Price-900 </button>
            </div>
          </div>
        </div> <!-- End Customer 1st Column-->

        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 2nd Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/food2.0.jpg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Dog Food With Real Chicken And Veggies</h4>
              <p class="card-text">100% Real Chicken AAnd Veggies <br> MRP-1000 <br> You Save-50</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-950 </button>
            </div>
          </div>
        </div> <!-- End Customer 2nd Column-->

        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 3rd Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/foo3.jpg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Natural Adult Dog Food</h4>
              <p class="card-text">With 100% natural presevaties<br> MRP-900 <br> You Save-50</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-850</button>
            </div>
          </div>
        </div> <!-- End Customer 3rd Column-->

        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 4th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/foo4.jpg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">100% Real Chicken Dog Food</h4>
              <p class="card-text">100% Chicken <br> MRP-900 <br> You Save-20</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-880 </button>
            </div>
          </div>
        </div> <!-- End Customer 4th Column-->

        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 5th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/food5.0.jpeg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Plant Powered Dog Food</h4>
              <p class="card-text">With refreshings mint<br> MRP-850 <br> You Save-50</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-700</button>
            </div>
          </div>
        </div> <!-- End Customer 5th Column-->
        
        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 6th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/food6.jpg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Corn Dog Food with 100% veggies</h4>
              <p class="card-text">made with vegetration formula<br> MRP-800 <br> You Save-50</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-750 </button>
            </div>
          </div>
        </div> <!-- End Customer 6th Column-->

        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 7th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/food7.0.jpg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Real Frits & Vegatables Dog Food</h4>
              <p class="card-text">Made In Turkey With Turkeyish formula<br> MRP-1000 <br> You Save-100</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-900</button>
            </div>
          </div>
        </div> <!-- End Customer 7th Column-->
        
        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 8th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/food8.jpg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Organic DoG Food</h4>
              <p class="card-text">With 100% organic Presevaties<br> MRP-300 <br> You Save-50</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-250</button>
            </div>
          </div>
        </div> <!-- End Customer 8th Column-->
        
        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 9th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/cat1.0.jpg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Fruits Cat Food with Red Cheeries</h4>
              <p class="card-text">with 100% real fruits<br> MRP-650 <br> You Save-50</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-600</button>
            </div>
          </div>
        </div> <!-- End Customer 9th Column-->
          
        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 10th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/cat2.png" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Real Sea Foods Cat Food</h4>
              <p class="card-text">Feeder With Food container<br> MRP-700 <br> You Save-50</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-650</button>
            </div>
          </div>
        </div> <!-- End Customer 10th Column--> 

        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 11th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/cat3.0.jpg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Active Adult Ocean Fish Cat Food</h4>
              <p class="card-text">With 100% real Fish<br> MRP-800 <br>You Save-50</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-750 </button>
            </div>
          </div>
        </div> <!-- End Customer 11th Column-->
        
        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 12th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/cat4.1.png" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Russian Persian Cat Food</h4>
              <p class="card-text">Made with ruusian food formula<br> MRP-900 <br>You Save-50</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-850 </button>
            </div>
          </div>
        </div> <!-- End Customer 12th Column--> 

        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 13th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/cat5.jpeg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Metabolic Nutrition Cat Food</h4>
              <p class="card-text">Chicken Flavoured food<br> MRP-900 <br>You Save-50</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-850</button>
            </div>
          </div>
        </div> <!-- End Customer 13th Column-->

        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 14th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/pigeon1.jpg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Premium Daily Pigeon Food</h4>
              <p class="card-text">with natural seeds<br> MRP-300 <br>  You Save-20</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-280</button>
            </div>
          </div>
        </div> <!-- End Customer 14th Column-->
        
        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 15th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/pigeon2.jpg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Manitoba Pigeon Food</h4>
              <p class="card-text">with premium seeds<br> MRP-400 <br> You Save-20</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-380</button>
            </div>
          </div>
        </div> <!-- End Customer 15th Column-->

        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 16th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/pigeon3.jpeg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Energy Wholemeal Pigeon Food</h4>
              <p class="card-text">Wholefood food<br> MRP-350 <br> You Save-20</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-330</button>
            </div>
          </div>
        </div> <!-- End Customer 16th Column-->
        
        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 17th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/pigeo4.jpg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Premium Bajra & Corn Pigeon Food</h4>
              <p class="card-text">real bajra & corn<br> MRP-500 <br>  You Save-20</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-480</button>
            </div>
          </div>
        </div> <!-- End Customer 17th Column-->
            
        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 18th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/rabbit1.jpeg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">100% Natural Rabbit Food</h4>
              <p class="card-text">100% natural persevaties<br> MRP-400 <br> You Save-30</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-370</button>
            </div>
          </div>
        </div> <!-- End Customer 18th Column-->
             
        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 18th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/rabbit2.jpg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Timoothy Natural Rabbit Food</h4>
              <p class="card-text">with added vitamins & minreals<br> MRP-450 <br> You Save-50</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-400</button>
            </div>
          </div>
        </div> <!-- End Customer 18th Column-->
                   
        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 18th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/rabbit3.jpeg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">vegetables Rabbit Food</h4>
              <p class="card-text">100% real veggies<br> MRP-430 <br> You Save-30</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-400</button>
            </div>
          </div>
        </div> <!-- End Customer 18th Column-->
                    
        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 19th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/rabbit4.jpeg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Nature's Rabbit Food</h4>
              <p class="card-text">Natures way of feeding<br> MRP-600 <br> You Save-50</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-550</button>
            </div>
          </div>
        </div> <!-- End Customer 19th Column-->

<?php
include('includes/footer.php'); 
$conn->close();
?>