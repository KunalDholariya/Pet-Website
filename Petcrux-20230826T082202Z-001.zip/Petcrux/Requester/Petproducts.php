<?php
define('TITLE', 'Pet Products');
define('PAGE', 'Petproducts');
include('includes/header.php');
include('../dbConnection.php');
?>

<div class="col-sm-9 col-md-10 mt-5 text-center">
  <p class=" bg-dark text-white p-2">Pet Products</p>
  <p>We are not providing online delivery services, you have to visit our store to purchase these products.</p>
  <div class="row mt-5">
        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 1st Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/soap1.jpeg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Neem Health Plus Soap</h4>
              <p class="card-text">Neem All Natural Soap <br> MRP-100 <br>  You Save-20</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-80</button>
            </div>
          </div>
        </div> <!-- End Customer 1st Column-->

        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 2nd Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/soap2.jpg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title"> Cedarwood Lavender Soap</h4>
              <p class="card-text">Soap & Slave Soap <br> MRP-200 <br> You Save-20</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold"> Our Price-180</button>
            </div>
          </div>
        </div> <!-- End Customer 2nd Column-->

        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 3rd Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/soap3.jpg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Tea Tree Oil Soap</h4>
              <p class="card-text">Fresh & Revitayiles Soap <br> MRP-120 <br> You Save-20</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-100</button>
            </div>
          </div>
        </div> <!-- End Customer 3rd Column-->

        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 4th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/soap4.jpg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Fresh Soap</h4>
              <p class="card-text">Fresh & Natural Soap <br> MRP-120 <br>  You Save-20</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-100 </button>
            </div>
          </div>
        </div> <!-- End Customer 4th Column-->

        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 5th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/Shampoo4.jpg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Aloe Vera & Jojoba Oil Shampoo</h4>
              <p class="card-text">Fresh aloe & jojoba <br> MRP-300 <br> You Save-50</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-250</button>
            </div>
          </div>
        </div> <!-- End Customer 5th Column-->
        
        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 6th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/s3.jpg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Oatmeal & Honey Shampoo</h4>
              <p class="card-text">Fresh honey and oats <br> MRP-300 <br> You Save-50</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-250 </button>
            </div>
          </div>
        </div> <!-- End Customer 6th Column-->

        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 7th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/shampoo2.jpg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Senstative Pet  Shampoo</h4>
              <p class="card-text">Amino Acid Senstative <br> MRP-300 <br> You Save-50</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-250 </button>
            </div>
          </div>
        </div> <!-- End Customer 7th Column-->
        
        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 8th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/shampoo1.jpg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Natural Nuts Shampoo</h4>
              <p class="card-text">All Natural Fresh Nuts Shampoo <br> MRP-300 <br>  You Save-50</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold"> Our Price-250</button>
            </div>
          </div>
        </div> <!-- End Customer 8th Column-->
        
        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 9th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/f1.jpg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Pet Feeder Bowl </h4>
              <p class="card-text">Feeder With Food container storage <br> MRP-800 <br>  You Save-50</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-750</button>
            </div>
          </div>
        </div> <!-- End Customer 9th Column-->
          
        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 10th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/fooder2.jpeg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title"> Jumpet Feeder Bowl </h4>
              <p class="card-text">Feeder With Food container  <br> MRP-700 <br>  You Save-50</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-650</button>
            </div>
          </div>
        </div> <!-- End Customer 10th Column--> 

        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 11th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/fooder3.jpg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Automatic Feeder with 2 Bowl </h4>
              <p class="card-text">Amt Feeder <br> MRP-1000 <br> You Save-50</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-950</button>
            </div>
          </div>
        </div> <!-- End Customer 11th Column-->
        
        <div class="col-lg-3 col-sm-6">
          <!-- Start Customer 12th Column-->
          <div class="card shadow-lg mb-2">
            <div class="card-body text-center">
            <img src="pictures/fooder4.jpg" class="img-fluid" style="border-radius: 100px;">
             <h4 class="card-title">Simple Feeder </h4>
              <p class="card-text">Feeder with normal bowl <br> MRP-400 <br> You Save-50</p>
              <button type="submit" class="btn btn-success mt-5 btn-block shadow-sm font-weight-bold">Our Price-350</button>
            </div>
          </div>
        </div> <!-- End Customer 12th Column-->

  <?php
include('includes/footer.php'); 
$conn->close();
?>